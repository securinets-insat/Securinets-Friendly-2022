// gcc main.c -o main -z relro -z now -no-pie

#include<stdio.h>
#include<stdlib.h>

int main(){

	char input[56];
	int target = 2022;

	puts("Do you have something to say?");
	read(0,input,64);
    printf("Your target is: %d\n", target);

    if(target != 2022){
        system("/bin/sh");
	}
	return 0;
}
